<?php

header("Access-Control-Allow-Origin:*");
header("content-type:text/html;charset=utf-8");
mysql_connect("localhost","root","");
mysql_select_db("haolilai");
mysql_query("set names 'utf8'");
$imgid=$_GET["imgid"];
$sql="SELECT name,price1,price2,des,spe1,spe2,ximg1,ximg2,bimg1,bimg2 FROM things WHERE id=$imgid";
$result=mysql_query($sql);
$arr1=array();
if($result){
	while ($arr=mysql_fetch_array($result)) {
		array_push($arr1,$arr);
	}
	//$json=array("data"=>$arr1);
	$json=json_encode($arr1);
	echo $json;
}
else{
	echo '{"code":0}';
}

?>