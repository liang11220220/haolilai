<?php

header("Access-Control-Allow-Origin:*");
header("content-type:text/html;charset=utf-8");
mysql_connect("localhost","root","");
mysql_select_db("haolilai");
mysql_query("set names 'utf8'");
$pagenum=$_GET["pagenum"];
$index=$_GET["index"];
$sear=$_GET["sear"];
$sql2="SELECT count(*) as count FROM things where name  like '%$sear%'";
$sql1="SELECT id,name,des,img FROM things where name like '%$sear%' limit ".($index-1)*$pagenum.",".$pagenum;
$result2=mysql_query($sql2);
$result1=mysql_query($sql1);
$arr1=array();
$result2=mysql_fetch_assoc($result2);
if($result1){
	while ($arr=mysql_fetch_array($result1)) {
		array_push($arr1,$arr);
	}
	$arr1=array("datacount"=>$result2["count"],"data"=>$arr1);
	$json=json_encode($arr1);
	echo $json;
}
else{
	echo '{"code":0}';
}
?>