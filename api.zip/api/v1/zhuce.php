<?php
header("Access-Control-Allow-Origin:*");
header("content-type:text/html;charset=utf-8");
mysql_connect("localhost","root","");
mysql_select_db("haolilai");
mysql_query("set names 'utf8'");
$newyonghu=$_GET["newyonghu"];
$newpassword=$_GET["newpassword"];
$newemail=$_GET["newemail"];
//echo $newyonghu;
$sql="INSERT INTO yonghu (tel,email,password) value ('$newyonghu','$newemail','$newpassword')";
$result=mysql_query($sql);
if($result){
	echo '{"code":1}';
}
else{
		echo '{"code":0}';
}
//echo  $yonghu;

mysql_close();
?>