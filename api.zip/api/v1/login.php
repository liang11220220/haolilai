<?php
header("Access-Control-Allow-Origin:*");
header("content-type:text/html;charset=utf-8");
mysql_connect("localhost","root","");
mysql_select_db("haolilai");
mysql_query("set names 'utf8'");
$yonghu=$_GET["yonghu"];
$mima=$_GET["mima"];
//echo  $yonghu;
$sql="SELECT tel FROM yonghu WHERE tel='$yonghu'AND password='$mima' OR email='$yonghu'AND password='$mima'";
$result=mysql_query($sql);

if($result){
	while ($arr=mysql_fetch_array($result)){
		$json=array("yonghu"=>$arr);
		$json=json_encode($json);
		echo $json;
	}
	/*echo '{"code":1}';*/
}
else{
	echo '{"code":0}';
}
mysql_close();
?>